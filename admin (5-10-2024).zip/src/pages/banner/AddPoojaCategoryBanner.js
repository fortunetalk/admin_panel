import React from 'react'

const AddPoojaCategoryBanner = () => {
  return (
    <div>AddPoojaCategoryBanner</div>
  )
}

export default AddPoojaCategoryBanner