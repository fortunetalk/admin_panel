<<<<<<< HEAD
import * as actionTypes from "../actionTypes";

export const getAllCountry = payload =>({
    type: actionTypes.GET_ALL_COUNTRY,
    payload
})

export const setAllCountry = payload =>({
    type: actionTypes.SET_ALL_COUNTRY,
    payload
})
=======
import * as actionTypes from "../actionTypes";

export const getAllCountry = payload =>({
    type: actionTypes.GET_ALL_COUNTRY,
    payload
})

export const setAllCountry = payload =>({
    type: actionTypes.SET_ALL_COUNTRY,
    payload
})
>>>>>>> b07d1d61d768eced612a3f10c59c155b26b274e7
